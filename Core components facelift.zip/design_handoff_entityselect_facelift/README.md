# Handoff: EntitySelect / Table Facelift (audako-core-components)

## Overview

Visual and structural facelift of the shared table and the `EntitySelect` dialog in
`audako-core-components` (Svelte 5 + Tailwind 4), plus `TenantSelect`. The goals were:
denser rows, a look aligned with the main application's "Signal auswählen" dialog, a
**reduced** table (no column filters, no feature-rich toolbar), and a decision on how
filtering should work.

Two filter approaches are documented and prototyped:

- **2c — Slideout panel**: generic per entity, opens over the table.
- **2d — Toolbar chip**: entity-specific fields as dropdown chips in the toolbar. **This one is interactive in the prototype.**

Both share the same table, tree, header and footer. Pick one before implementing; do not
build both.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes that show
the intended look and behaviour. They are **not production code to copy**. They are written
as "Design Components" (a small HTML runtime, `support.js`) purely so they render and can be
clicked through in a browser.

The task is to **recreate these designs inside `audako-core-components`** using its existing
environment: Svelte 5 runes (`$props`, `$state`, `$derived`), Tailwind 4 utility classes, the
existing `shared/components/*` primitives (`Checkbox`, `IconButton`, `Table`, `HeaderRow`,
`HeaderCell`, `DataRow`, `DataCell`, `Paginator`, `Menu`, `PopupContainer`, `Select`), and
`Material Symbols Rounded` for icons. Do not introduce a new component library, and do not
port the inline styles from the prototype — translate them to Tailwind classes and the
project's existing tokens.

**Icon note:** the prototype draws icons as inline SVG paths (Material Symbols outlines) only
because it had no icon-font dependency. In the real implementation keep using the existing
`Material Symbols Rounded` font with the ligature names listed per component below.

## Fidelity

**High fidelity.** Colors, sizes, spacing, radii and states below are exact and were derived
from a screenshot of the production "Signal auswählen" dialog plus the bound design system.
Recreate the UI pixel-perfectly, but express every value through Tailwind classes / existing
component props rather than hard-coded inline styles.

One deliberate deviation from production: **row height is 38px instead of 46px** (the request
was "kompakter"). If density turns out to be too tight in real data, 46px is the fallback and
nothing else in the spec changes.

---

## Design Tokens

All values are literal; there is no token file in the prototype.

### Colors

| Purpose | Value |
| --- | --- |
| Primary (brand magenta) | `rgb(178, 24, 122)` |
| Primary hover / pressed | `rgb(140, 18, 96)` |
| Primary tint (active nav, chip fill, icon-tile bg, hover on primary icon button) | `rgba(178, 24, 122, 0.10)` |
| Primary tint, subtle (tenant search button hover) | `rgba(178, 24, 122, 0.08)` |
| Checkbox / selection blue | `rgb(25, 118, 210)` |
| Text primary | `rgba(0, 0, 0, 0.86)` |
| Text secondary | `rgba(0, 0, 0, 0.58)` |
| Text tertiary / meta | `rgba(0, 0, 0, 0.40)` |
| Text disabled / inactive pager arrow | `rgba(0, 0, 0, 0.25)` |
| Checkbox border (unchecked) | `rgba(0, 0, 0, 0.45)`, 2px |
| Divider / border (dialog, table, inputs) | `rgba(0, 0, 0, 0.12)` |
| Row separator | `rgba(0, 0, 0, 0.08)` |
| Row hover | `rgba(0, 0, 0, 0.035)` |
| Row active / current | `rgba(0, 0, 0, 0.08)` |
| Neutral icon-button hover | `rgba(0, 0, 0, 0.045)` |
| Muted panel background | `rgba(0, 0, 0, 0.035)` |
| Warning / no permission | `rgb(198, 40, 40)` |
| Warning tint | `rgba(198, 40, 40, 0.10)`, border `rgba(198, 40, 40, 0.35)` |
| Surface | `#ffffff` |
| Page backdrop (prototype canvas only) | `#eeeeee` |

**Important:** selection is **not** tinted magenta. Magenta marks the active tree node, the
active toolbar toggle, chips, links and the primary button. Checked rows are indicated by the
blue checkbox only; the grey `rgba(0,0,0,.08)` background marks the *current/active* row.

### Typography

Roboto (already used by the app), weights 400 / 500 / 600.

| Role | Size | Weight |
| --- | --- | --- |
| Dialog title | 18px | 400 |
| Section title ("Einträge gesamt: N") | 17px | 400 |
| Footer selection count | 15px | 400 |
| Table header cell | 13.5px | 400, color `rgba(0,0,0,.58)` |
| Table cell / tree node / list item | 13.5px | 400 |
| Buttons | 13.5px | 500 |
| Chips, filter labels, paginator | 12.5px – 13px | 400 / 500 |
| Meta line (second line in list rows) | 11.5px | 400, `rgba(0,0,0,.40)` |
| Field label ("Mandant") | 11px | 400, `rgba(0,0,0,.40)` |
| Badge (filter count) | 10.5px | 400, white on primary |

### Spacing, radii, sizes

| Token | Value |
| --- | --- |
| Dialog radius | 10px |
| Dialog shadow | `0 5px 5px -3px rgba(0,0,0,.2), 0 8px 10px 1px rgba(0,0,0,.14), 0 3px 14px 2px rgba(0,0,0,.12)` |
| Card / table container radius | 10px |
| Control radius (inputs, selects, segmented, icon-square) | 8px |
| Button radius | 6px |
| Checkbox radius | 3px |
| Chip / badge radius | 999px |
| Button height | 36px |
| Input height (toolbar filter, tree search) | 40px |
| Tenant card height | 44px |
| Round icon button | 40px (toolbar), 36px (dialog close), 26px (inline) |
| Icon sizes | 22px toolbar, 20px header tile / tenant, 18px inline, 16px tree chevron, 14px checkbox glyph |
| Table header row | 40px |
| Table data row | 38px |
| Tree node padding | 8px 10px, indent 12px per level |
| Paginator row | 44px |
| Dialog header padding | 12px 12px 12px 18px |
| Dialog footer padding | 12px 18px |
| Right pane padding | 14px 20px |
| Left panel width | 280px |
| Filter slideout width (2c) | 300px |
| Type dropdown width (2d) | 240px |

---

## Screens / Views

### 1. EntitySelect dialog — shell (shared by 2c and 2d)

**Purpose:** pick one or many entities (here: signals) from a tenant's group tree.

**Layout:** 1280 × 660 dialog, `display: flex; flex-direction: column`, radius 10px,
`overflow: hidden`.

1. **Header** (fixed): 40×40 rounded-square (radius 10px) with primary tint background and a
   primary-colored entity icon; title "Signal auswählen" at 18px; spacer; 36px round close
   button (`close`), neutral, hover `rgba(0,0,0,.045)`. Bottom border `rgba(0,0,0,.12)`.
2. **Body** (`flex: 1; min-height: 0; display: flex`): left panel 280px fixed, right pane
   flexible.
3. **Footer** (fixed): selection count on the left at 15px ("2 Ausgewählt"), then
   "Abbrechen" (secondary button) and "Übernehmen" (primary button with leading `check`
   icon, 18px, 8px gap). Top border `rgba(0,0,0,.12)`.

### 2. Left panel (280px)

Column, three stacked regions.

**a) Tenant + search (fixed, padding 12px 12px 10px)**

- Tenant card: 44px tall, 1px border `rgba(0,0,0,.12)`, radius 8px, padding `0 8px 0 10px`,
  8px gap. Contents: 18px `domain` icon (secondary), two-line block (label "Mandant" 11px
  tertiary / tenant name 13.5px, both `line-height: 1.2`, name truncates with ellipsis),
  16px `unfold_more` icon. Hover: border `rgba(0,0,0,.3)`. Click opens TenantSelect.
- Next to it, a 44×44 square button, 1px border, radius 8px, primary-colored `search` icon
  (20px), hover background `rgba(178,24,122,.08)` — opens tenant search.
- Below (10px gap): 40px search input, 1px border, radius 8px, padding `0 10px 0 12px`,
  placeholder "Suche", trailing 18px `search` icon in tertiary. Focus-within: border becomes
  primary. This searches the **tree**, not the table.

**b) Tree (scrollable, `flex: 1`, padding 2px 10px 10px)**

- Node: `display: flex; align-items: center; gap: 6px; padding: 8px 10px; border-radius: 8px`.
- Leading chevron: 16px `expand_more` (open) / `chevron_right` (closed). Leaf nodes have no
  chevron and get `padding-left: 26px` instead.
- Label `flex: 1`, truncated; trailing entity count 12.5px in `rgba(0,0,0,.40)`.
- Indent: each level wraps children in a container with `padding-left: 12px`.
- **Default:** text `rgba(0,0,0,.58)`.
- **Hover:** background `rgba(0,0,0,.045)`.
- **Active:** background `rgba(178,24,122,.10)`, text primary, `font-weight: 500`, plus a
  3px `border-left` in primary (inactive nodes carry `border-left: 3px solid transparent`
  so labels never shift).

**c) "Zuletzt ausgewählt" (fixed, top border, padding 10px 10px 12px)**

- Heading row: "Zuletzt ausgewählt" 12.5px secondary, right-aligned link "alle übernehmen"
  12px primary.
- Items: `padding: 7px 10px; gap: 10px; border-radius: 8px`, hover `rgba(0,0,0,.045)`.
  16px checkbox reflecting current selection, then a two-line block: entity name 13.5px
  (truncated) and group 11.5px `rgba(0,0,0,.40)`.
- Shows the last 3–5 entities the user picked previously; clicking toggles selection
  directly without navigating the tree.

### 3. Right pane — toolbar

`display: flex; align-items: center; gap: 12px; margin-bottom: 10px`.

1. `Einträge gesamt: {n}` — 17px, `flex: none`, reflects the filtered count.
2. Full-text filter input — `flex: 1; min-width: 120px`, 40px tall, border
   `rgba(0,0,0,.12)`, radius 8px, placeholder "Filter", trailing 18px `search` icon,
   focus-within border primary. **Always visible.**
3. Filter control — differs per variant, see 2c / 2d below.
4. Subgroup toggle — **always visible**, 40px round icon button, no border, no fill.
   - **On:** primary icon `layers` (22px), hover `rgba(178,24,122,.10)`, tooltip
     "Untergruppen einbezogen".
   - **Off:** `rgba(0,0,0,.45)` icon `folder`, hover `rgba(0,0,0,.045)`, tooltip
     "Nur diese Gruppe".

### 4. Right pane — table (basics only)

Container: `flex: 1; min-height: 0`, 1px border `rgba(0,0,0,.12)`, radius 10px,
`overflow: auto`.

**Columns** (exactly these four plus the checkbox gutter):

| Column | Width | Notes |
| --- | --- | --- |
| checkbox gutter | 46px fixed, `padding-left: 16px` | header holds select-all |
| Name | `flex: 1`, truncated | **only sortable column** |
| Gruppe | 200px fixed | |
| Typ | 110px fixed | |
| Signalwert | 120px fixed, `padding-right: 16px` | |

**Header row:** 40px, `position: sticky; top: 0`, white background, bottom border
`rgba(0,0,0,.12)`, `z-index: 1`, text 13.5px `rgba(0,0,0,.58)`. Non-first columns get
`padding-left: 12px` and a `border-left: 1px solid rgba(0,0,0,.12)` — these vertical rules
are what makes the header read like the production table. The Name cell shows a 14px
`arrow_upward` / `arrow_downward` sort glyph; the other three headers are **not** clickable
(no pointer cursor, no hover).

Select-all checkbox: indeterminate state = blue fill with a white `remove` glyph.

**Data row:** 38px, bottom border `rgba(0,0,0,.08)`, `cursor: pointer`, hover
`rgba(0,0,0,.035)`, click toggles selection.
- Checkbox 16px: unchecked = 2px border `rgba(0,0,0,.45)`, radius 3px; checked = filled
  `rgb(25,118,210)` with white 14px `check`.
- Name 13.5px truncated; Gruppe and Typ 13.5px `rgba(0,0,0,.58)`; Signalwert 13.5px primary
  text color.
- **No permission:** row background `rgba(198,40,40,.10)`, text `rgb(198,40,40)`, checkbox
  border `rgba(0,0,0,.15)`, `cursor: default`, checkbox non-interactive, trailing text
  "Keine Berechtigung".
- **Active/current row:** background `rgba(0,0,0,.08)`.

**Empty state** (inside the container): centered column, 40px vertical padding, 24px
`search_off` icon, "Keine Signale für diese Filter" 13.5px, and a primary 12.5px reset link.

**Loading:** 2px indeterminate bar directly under the header row, track
`rgba(178,24,122,.15)`, indicator primary, 1s linear loop (the existing
`indeterminateAnimation` keyframes).

### 5. Right pane — paginator

44px row, right-aligned, 10px gap, 13px `rgba(0,0,0,.58)`:
"Zeilen" · rows-per-page select (30px tall, border, radius 8px, trailing 16px
`arrow_drop_down`) · "1 - {shown} / {total}" · a single bordered group (30px tall, radius
8px) with four 34px buttons `first_page`, `navigate_before`, `navigate_next`, `last_page`
separated by 1px `rgba(0,0,0,.08)` dividers. Disabled arrows are `rgba(0,0,0,.25)` with
`cursor: default`.

Optional, matching production: a "Gehe zu" button before "Zeilen".

---

## Variant 2c — Slideout filter panel

Use this if more entity-specific filter fields are coming (status, time range, tags, …).

- Toolbar item 3 is a neutral 40px round icon button with a `filter_alt` icon and a **badge**:
  absolutely positioned at `top: -1px; right: -1px`, min-width 16px, height 16px, padding
  `0 4px`, radius 999px, primary background, white 10.5px text, `pointer-events: none`.
  The button itself is **neutral grey**, not primary — only the badge carries the accent.
- Below the toolbar, an **active-filter chip row** (26px chips, 1px border, radius 999px,
  12.5px text) with a trailing 14px `close` per chip and a primary "Filter zurücksetzen" link.
- The panel is an **overlay**, not a layout column — the table must not reflow when it opens:
  `position: absolute; top: 100px; right: 20px; bottom: 58px; width: 300px`, white, 1px
  border, radius 10px, shadow `0 8px 28px rgba(0,0,0,.14)`, `overflow: hidden`.
  The offsets are deliberate: `top: 100px` clears the toolbar and the chip row, `bottom: 58px`
  clears the paginator, so **filter input, subgroup toggle and pagination stay usable while
  the panel is open**. Keep this constraint if you change the geometry.
- Panel structure: 52px header ("Filter" 15px/500 + 36px round close), scrollable body
  (padding 16px 18px, 20px gaps), footer with two equal-width buttons "Zurücksetzen"
  (secondary) and "Anwenden" (primary).
- Panel body is **generic per entity**. For `Signal` it currently contains only a "Typ"
  group: label 12.5px secondary, then checkbox rows (16px checkbox, 10px gap, label
  `flex: 1`, count 12.5px tertiary). A muted info block at the top explains that content is
  entity-driven — that block is documentation for the review, not a required UI element.

## Variant 2d — Toolbar chip filter (interactive prototype)

Use this if `Signal` (and most entities) will stay at one or two filter fields.

- Toolbar item 3 is a **dropdown chip**: 32px tall, radius 999px, padding `0 12px`, 7px gap,
  13px text, trailing 16px `arrow_drop_down`, `white-space: nowrap`.
  - **No selection (default):** label "Typ: alle", 1px border `rgba(0,0,0,.12)`, white
    background, text `rgba(0,0,0,.58)`, hover `rgba(0,0,0,.035)`.
  - **One selected:** label "Typ: Analog", 1px border primary, background
    `rgba(178,24,122,.10)`, text primary, `font-weight: 500`.
  - **Several selected:** label "Typ: 2 gewählt", same active styling.
- Clicking the chip toggles a **popup**: `position: absolute; top: 60px; right: 70px;
  width: 240px`, white, 1px border, radius 10px, shadow `0 8px 28px rgba(0,0,0,.16)`,
  padding 6px, `z-index: 2`. In the real implementation anchor it to the chip via the
  existing `PopupContainer` / `Menu` rather than fixed offsets.
- Popup rows: `padding: 8px 10px; gap: 10px; border-radius: 8px`, hover `rgba(0,0,0,.045)`,
  16px checkbox, label `flex: 1`, live count 12.5px tertiary.
- Popup footer: 1px divider, then a row with "zurücksetzen" (12.5px secondary) and "fertig"
  (12.5px primary, weight 500).
- No separate chip row is needed — the chip itself shows the active filter.

---

## Interactions & Behavior

Implemented and clickable in `2d` of the prototype; the same behaviour applies to `2c`.

| Trigger | Result |
| --- | --- |
| Click type chip | Toggle dropdown open/closed |
| Click type row in dropdown | Toggle that type in the filter set; table, counts, "Einträge gesamt" and paginator update immediately |
| "zurücksetzen" | Clear all type filters → chip returns to neutral "Typ: alle" |
| "fertig" | Close the dropdown (filters already applied — apply is live, not deferred) |
| Click subgroup toggle | Include/exclude descendant groups; type counts recalculate against the new scope |
| Click a table row (anywhere) | Toggle its selection; footer count updates |
| Click header checkbox | Clear selection (indeterminate) / select all on the page |
| Click a tree node | Load that group into the table; **selection is preserved across group changes** |
| Click an item in "Zuletzt ausgewählt" | Toggle that entity's selection without navigating |
| Click tenant card | Open TenantSelect |
| "Übernehmen" | Return the selected entities and close |

Notes:
- Filters apply **live**; the 2c panel's "Anwenden" is a confirm/close affordance, not a
  deferred commit. If you prefer deferred apply, make that consistent across both variants.
- Filtering and the subgroup toggle both reset pagination to page 1.
- No-permission rows are never selectable and are excluded from select-all.
- Hover feedback is background-only; nothing moves or resizes on hover.

## State Management

Per dialog instance:

| State | Type | Notes |
| --- | --- | --- |
| `tenant` | tenant ref | drives the tree |
| `activeGroup` | group ref | current tree selection |
| `includeSubgroups` | boolean | default `true` |
| `search` | string | tree search (left panel) |
| `filterText` | string | table full-text filter, debounced (the existing code uses `debounceTime`) |
| `typeFilter` | string[] | empty array = no restriction |
| `popupOpen` / `panelOpen` | boolean | 2d / 2c respectively |
| `selection` | entity[] | survives group and tenant changes |
| `recent` | entity[] | last selected, persisted across dialog opens |
| `page`, `pageSize` | number | `pageSize` default 25 |
| `sort` | `{ field: 'name', dir: 'asc' \| 'desc' }` | only `name` is sortable |
| `loading` | boolean | drives the indeterminate bar |

Data fetching: entity list per `(tenant, activeGroup, includeSubgroups, filterText,
typeFilter, sort, page, pageSize)`; type counts per `(tenant, activeGroup,
includeSubgroups)` — the counts shown next to each type must respect the current scope but
**not** the current type selection.

## Assets

- **Icons:** `Material Symbols Rounded` (already in the repo at
  `src/assets/MaterialSymbolsRounded.woff2`, copied here under `assets/`). Ligatures used:
  `close`, `search`, `domain`, `unfold_more`, `expand_more`, `chevron_right`, `arrow_upward`,
  `arrow_downward`, `arrow_drop_down`, `check`, `remove`, `layers`, `folder`, `filter_alt`,
  `first_page`, `navigate_before`, `navigate_next`, `last_page`, `search_off`, `history`,
  `block`.
  The prototype inlines equivalent SVG paths only to avoid a font dependency — use the font.
- **Fonts:** Roboto 400/500/600.
- No images or illustrations.

## Files

| File | Contents |
| --- | --- |
| `Core Components - Facelift.dc.html` | All facelift directions on one canvas. Top to bottom: **2d** (toolbar chip, interactive), **2c** (slideout panel, final direction), 2b/2a (earlier filter explorations), 1a–1c (earlier layout explorations), **1d** (states & building blocks sheet: row states, checkbox, icon button, chips, buttons, tree node, empty, skeleton, plus TenantSelect). |
| `Core Components — Heute.dc.html` | The current UI rebuilt 1:1 from the Svelte source, for before/after comparison. |
| `support.js` | Runtime required to open the two HTML files in a browser. Not part of the deliverable. |
| `assets/MaterialSymbolsRounded.woff2` | Icon font used by the "Heute" file. |
| `screenshots/00-heute-vorher.png` | Current UI (before). |
| `screenshots/2d-toolbar-chip.png` | Variant 2d — toolbar chip filter. |
| `screenshots/2c-slideout-filter.png` | Variant 2c — slideout filter panel, open. |
| `screenshots/1d-states-bausteine.png` | States & building blocks sheet + TenantSelect. |

Open either HTML file directly in a browser. Only `2c` and `2d` are current — the lower
sections are kept for context and should not be implemented.

### Source components this replaces

`src/shared/components/table/{Table,HeaderRow,HeaderCell,DataRow,DataCell,Paginator}.svelte`,
`src/shared/components/checkbox/Checkbox.svelte`,
`src/shared/components/icon-button/IconButton.svelte`,
`src/components/entity-select/{EntitySelect,EntitySelectDialog,EntitySelectSidebar,EntitySelectFilter,EntitySelectTable,EntitySelectTreeNode}.svelte`,
`src/components/tenant-select/TenantSelect.svelte`.

### Open decisions

1. **2c or 2d** — depends on whether more filter fields are coming per entity.
2. Row height 38px vs. production 46px.
3. Whether the "Signalwert" column stays in the basic table (it is in the prototype and in
   production, but it needs live values).
